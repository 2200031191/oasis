function convertTemperature() {
    const tempInput = parseFloat(document.getElementById('tempInput').value);
    const unit = document.getElementById('unitSelect').value;
    let resultText = '';

    if (isNaN(tempInput)) {
        resultText = 'Please enter a valid number.';
    } else {
        switch (unit) {
            case 'celsius':
                resultText = `
                    Fahrenheit: ${(tempInput * 9/5 + 32).toFixed(2)} °F<br>
                    Kelvin: ${(tempInput + 273.15).toFixed(2)} K
                `;
                break;
            case 'fahrenheit':
                resultText = `
                    Celsius: ${((tempInput - 32) * 5/9).toFixed(2)} °C<br>
                    Kelvin: ${((tempInput - 32) * 5/9 + 273.15).toFixed(2)} K
                `;
                break;
            case 'kelvin':
                resultText = `
                    Celsius: ${(tempInput - 273.15).toFixed(2)} °C<br>
                    Fahrenheit: ${((tempInput - 273.15) * 9/5 + 32).toFixed(2)} °F
                `;
                break;
        }
    }

    document.getElementById('result').innerHTML = resultText;
}
